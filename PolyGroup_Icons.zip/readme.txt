Pak deze files uit naar 
C:\Program Files (x86)\LEGO Software\LEGO MINDSTORMS * EV3\Resources\MyBlocks\images

Dit zijn de icons die horen bij Grote_Blokken.ev3s.

